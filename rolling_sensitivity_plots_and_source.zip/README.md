# Three-slide presentation

Compile rolling_sensitivity_three_slides.tex twice with pdflatex. Run make_plots.py with numpy and matplotlib to regenerate all plots. All examples are synthetic.

Slide 1 gives the exact rolling OLS identity, assuming both Gram matrices are invertible. Both entering and departing residuals are evaluated using the old estimate. The relative Gram-matrix condition is sufficient for a small relative inverse change, rather than a claim that every one-row window move is small. The displayed classical SE formula assumes fixed design, a correct conditional mean, and uncorrelated equal-variance errors. It is not a calibrated probability of the next update or a numerical-roundoff error measure. Under the stable classical model with an independent new error, the incoming prediction error has variance sigma^2(1+h_plus); the departing fitted residual has variance sigma^2(1-h_minus). Their different scales matter for formal surprise assessment.

Slide 2 compares five observations with x=(-2,-1,0,1,2) and x=(-4,-2,0,2,4), in both cases y=x. The added points are (4,4), (0,8), and (4,8). There is an intercept. The script checks each refitted coefficient vector against the exact addition identity. Larger predictor spread improves slope information here. Because the original points lie exactly on a line, their fitted residual variance is zero; these figures illustrate sensitivity, not empirical SE estimation. PDF and PNG files are provided for each of the six plots and the combined panel.

Slide 3 constructs a rank-one coefficient-change matrix as (1,0.5)^T (0.4,0.3,0.2). The curves share a ramp over times 15 to 25. Positive loadings make the changes move in the same direction; low rank does not generally require positive co-movement or establish causality.
