from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
navy='#16324F';teal='#008C95';red='#D65345'
fig,axs=plt.subplots(2,3,figsize=(12.7,5.25),sharex=True,sharey=True)
cases=[(4,4,'Unusual input, zero residual'),(0,8,'Large residual at the centre'),(4,8,'Unusual input + residual')]
for row,scale in enumerate([1,2]):
 x=scale*np.arange(-2,3,dtype=float); X=np.c_[np.ones(5),x]; y=x.copy(); b=np.linalg.lstsq(X,y,rcond=None)[0];G=X.T@X
 for col,(xn,yn,title) in enumerate(cases):
  ax=axs[row,col];z=np.array([1,xn]);bn=np.linalg.lstsq(np.vstack([X,z]),np.r_[y,yn],rcond=None)[0]
  exact=np.linalg.solve(G,z)*(yn-z@b)/(1+z@np.linalg.solve(G,z))
  assert np.allclose(bn-b,exact)
  q=np.linspace(-4.5,4.6,100);ax.plot(q,q,color=navy,lw=1.7,label='Old fit');ax.plot(q,bn[0]+bn[1]*q,color=teal,lw=2,ls='--',label='New fit')
  ax.scatter(x,y,c=navy,s=28,zorder=3);ax.scatter([xn],[yn],c=red,s=65,zorder=5)
  if yn!=xn:ax.plot([xn,xn],[xn,yn],color=red,ls=':',lw=1.5)
  ax.set_xlim(-4.7,4.8);ax.set_ylim(-5,10);ax.grid(alpha=.15)
  if row==0:ax.set_title(title,fontsize=11,pad=10)
  ax.text(.04,.91,rf'$e_+={yn-xn},\quad\Delta\hat\beta={(0 if abs(bn[1]-1)<1e-10 else bn[1]-1):.3f}$',transform=ax.transAxes,fontsize=10)
  if col==0:ax.set_ylabel(('Weak slope information\n'+r'$S_{xx}=10$') if row==0 else ('Stronger slope information\n'+r'$S_{xx}=40$'))
  if row==1:ax.set_xlabel('Predictor x')
  f,a=plt.subplots(figsize=(4.4,3.2))
  for line in ax.lines:a.plot(line.get_xdata(),line.get_ydata(),color=line.get_color(),ls=line.get_linestyle(),lw=line.get_linewidth())
  a.scatter(x,y,c=navy,s=28);a.scatter([xn],[yn],c=red,s=65);a.set(xlim=(-4.7,4.8),ylim=(-5,10),xlabel='Predictor x',ylabel='Response y',title=title+'\n'+rf'$S_{{xx}}={int(x@x)},\ \Delta\hat\beta={(0 if abs(bn[1]-1)<1e-10 else bn[1]-1):.3f}$');f.tight_layout()
  for ext in ['pdf','png']:f.savefig(P/f'influence_{row+1}_{col+1}.{ext}',dpi=220)
  plt.close(f)
axs[0,2].legend(loc='lower right',fontsize=9)
fig.tight_layout(h_pad=1.4)
for ext in ['pdf','png']:fig.savefig(P/f'six_influence_plots.{ext}',dpi=220)
plt.close(fig)
t=np.arange(41);h=np.clip((t-15)/10,0,1);a=np.array([.4,.3,.2]);v=np.array([1,.5]);delta=np.outer(v,a)
fig,axs=plt.subplots(1,2,figsize=(8,3.4),sharey=True)
for k,ax in enumerate(axs):
 for j,c in enumerate([navy,teal,red]):ax.plot(t,v[k]*a[j]*h,color=c,lw=2.6,label=f'Market {chr(65+j)}')
 ax.axvspan(15,25,color='#edf3f5',zorder=0);ax.set(title=['Gas coefficient','Coal coefficient'][k],xlabel='Time',ylabel='Change from initial coefficient' if k==0 else '',ylim=(-.02,.45));ax.grid(alpha=.18)
axs[0].legend(frameon=False,fontsize=9,loc='upper left');fig.tight_layout()
for ext in ['pdf','png']:fig.savefig(P/f'shared_coefficient_changes.{ext}',dpi=220)
np.savetxt(P/'shared_change_matrix.csv',delta,delimiter=',',header='Market_A,Market_B,Market_C')
print('All six OLS updates verified against exact identity; shared matrix rank:',np.linalg.matrix_rank(delta))
