from pathlib import Path
import re,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
base=R/'previous_source.tex'
s=base.read_text();F=re.findall(r'\\begin\{frame\}.*?\\end\{frame\}',s,re.S);f={x.splitlines()[0]:x for x in F}
def get(title):return next(x for x in F if '{'+title+'}' in x.splitlines()[0])
def frame(title,body):return '\\begin{frame}[t]{'+title+'}\n'+body+'\n\\end{frame}'
navy='#3633AC';teal='#008A87'
rng=np.random.default_rng(38);x=np.cumsum(rng.normal(0,.35,240));u=np.zeros(240);u[0]=rng.normal(0,.35/np.sqrt(1-.5**2))
for t in range(1,240):u[t]=.5*u[t-1]+rng.normal(0,.35)
y=2+1.5*x+u
assert np.allclose(y-2-1.5*x,u)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#243047','text.color':'#243047','pdf.fonttype':42})
fig,axs=plt.subplots(2,1,figsize=(6.4,4.25),sharex=True)
axs[0].plot(x,color=navy,label='$x_t$');axs[0].plot(y,color=teal,label='$y_t$');axs[0].set_title('Two nonstationary series');axs[0].legend(frameon=False,ncol=2,fontsize=9)
axs[1].plot(y-2-1.5*x,color=teal);axs[1].axhline(0,color='#8792A5',lw=.7);axs[1].set_title(r'Stationary combination: $y_t-2-1.5x_t=u_t$');axs[1].set_xlabel('Observation');fig.tight_layout();fig.savefig(R/'cointegration_example.pdf',bbox_inches='tight');plt.close(fig)
new=[]
new.append(get('From cointegration to better updates'))
new.append(frame('Regression, spurious regression, cointegration and causality',r'''
\small\vspace{.3cm}
\renewcommand{\arraystretch}{1.55}
\begin{tabular}{P{3.4cm}P{9.5cm}}
\textbf{Regression}&Fits a relationship between a response and predictors. It can serve prediction without a causal interpretation.\\
\textbf{Spurious regression}&Unrelated persistent series can produce a strong-looking fit and misleading conventional significance.\\
\textbf{Cointegration}&A fixed linear combination of nonstationary series is stationary: their stochastic trends cancel.\\
\textbf{Causal relation}&Changing one variable through an intervention changes another. Cointegration alone does not establish this.\\
\end{tabular}
\vspace{.45cm}\take{Moving together is not enough to establish either cointegration or causality.}
\refs{Yule (1926); Granger--Newbold (1974); Engle--Granger (1987).}'''))
new.append(frame('Cointegration: the common trend cancels',r'''
\begin{columns}[c]
\begin{column}{.43\textwidth}
\[x_t=s_t,\qquad y_t=\alpha+\beta s_t+u_t\]
\[\boxed{y_t-\alpha-\beta x_t=u_t\sim I(0)}\]
$s_t$: a random walk.\par
$u_t$: a stationary deviation.\par\vspace{.25cm}
\textbf{Illustration:} $\alpha=2$, $\beta=1.5$.\par
The correctly weighted combination removes the common trend.
\end{column}
\begin{column}{.54\textwidth}
\includegraphics[width=\linewidth]{cointegration_example.pdf}
\end{column}
\end{columns}
\vspace{.2cm}\take{A cointegration test assesses evidence for a stationary combination from a finite sample.}
\refs{Engle--Granger (1987).}'''))
new.extend([get('Four settings, increasing difficulty'),get('Online, multiple regimes: decide before the future arrives')])
new.append(frame('Engle--Granger: evidence from one fixed sample',r'''
\vspace{.35cm}
\textbf{1. Estimate the long-run relation}
\[y_t=\alpha+\beta x_t+u_t,\qquad \hat u_t=y_t-\hat\alpha-\hat\beta x_t.\]
\textbf{2. Test the fitted residuals for a unit root}\par
$H_0$: no cointegration. Use residual-based cointegration critical values.
\vspace{.4cm}
\textcolor{navy}{\textbf{What improves with a longer sample?}}\par
Within one stable cointegrated regime, under standard assumptions:
\[\hat\beta_T-\beta=O_p(T^{-1}),\qquad
\Pr(\text{reject }H_0\mid\text{fixed cointegrated alternative})\longrightarrow1.\]
\take{Long-run identification needs a stable relation across the estimation sample.}
\refs{Engle--Granger (1987); Stock (1987).}'''))
new.append(frame('Rolling windows: faster adaptation uses less information',r'''
\vspace{.35cm}
At each date, drop the oldest observation and add the newest.\par
Re-estimate the slope and re-test the fitted residuals.
\vspace{.45cm}
\begin{columns}[T]
\begin{column}{.46\textwidth}\textcolor{navy}{\textbf{Longer window}}\par More information within a stable regime.\par\vspace{.15cm}After a break, old observations persist and can bias the current fit.\end{column}
\begin{column}{.46\textwidth}\textcolor{teal}{\textbf{Shorter window}}\par Old-regime observations leave sooner.\par\vspace{.15cm}Fewer observations generally mean more uncertain coefficients and weaker tests.\end{column}
\end{columns}
\vspace{.5cm}\take{We want fast adaptation, but a short window makes the replacement harder to estimate.}
\refs{Vidyamurthy (2004); Rad--Low--Faff (2016).}'''))
new.append(frame('Two quantities fluctuate',r'''
\vspace{.15cm}
\begin{columns}[T]
\begin{column}{.49\textwidth}
\begin{tikzpicture}\begin{axis}[deck,xmin=59,height=3.0cm,title={The coefficient $\hat\beta_t$}]
\addplot[navy] coordinates {\betadata};\addplot[gray,dashed] coordinates {(59,1)(239,1)};
\end{axis}\end{tikzpicture}
\small
\[\Delta\hat\beta_t=\Delta\beta_t^\star+\Delta e_t+\Delta n_t.\]
True change + statistical error change + numerical error change.
\end{column}
\begin{column}{.49\textwidth}
\begin{tikzpicture}\begin{axis}[deck,xmin=59,height=3.0cm,ymin=0,ymax=.15,title={The cointegration p-value}]
\addplot[orange] coordinates {\pdata};\addplot[gray,dashed] coordinates {(59,.05)(239,.05)};
\end{axis}\end{tikzpicture}
\small\textbf{Repeated-look problem}\par
A 5\% test at every date does not provide 5\% overall false-alarm control. Overlapping windows are dependent.
\end{column}
\end{columns}
\vspace{.3cm}\take{Our first focus is the coefficient: why does it move, and can we anticipate it?}
\refs{Engle--Granger (1987); Howard et al. (2021).}'''))
new.append(get('Main problem: true change or estimation noise?').replace(r'\vspace{.22cm}',r'\vspace{.05cm}'))
new.extend([get('A moving window: fragile design amplifies two surprises'),get('Does an unusual observation really move the slope?'),get('Standard error: how uncertain is the estimated coefficient?')])
emp=get('SE anticipates the fragile periods')
emp=emp.replace('High SE combines weak information and high noise. If these persist, large movements remain likely.',r'\textbf{Exploratory data:} Yahoo Finance daily adjusted prices, QQQ and SPY.\par $\log P_t^{\rm SPY}=\alpha+\beta\log P_t^{\rm QQQ}+u_t$; 120-day windows, 2,452 evaluated dates.')
emp=emp.replace('SE predicts fluctuation; it does not tell us which replacement is useful.','Pair selected on the first 504 daily returns; evaluation is exploratory, with early selection overlap.')
new.append(emp)
new.append(get('After filtering: retained dates have less future fluctuation'))
new.append(frame('Why blocking uncertain periods can be costly',r'''
\small\vspace{.3cm}
The filter excludes \textbf{45.4\% of evaluated dates} in the QQQ/SPY example.
\vspace{.35cm}
\begin{columns}[T]
\begin{column}{.46\textwidth}\textcolor{navy}{\textbf{Potential financial cost}}\par
Fewer opportunities to enter positions.\par\vspace{.15cm}
True changes can raise uncertainty, so the filter may also delay re-entry after a regime change.
\end{column}
\begin{column}{.46\textwidth}\textcolor{teal}{\textbf{What the experiment establishes}}\par
Retained dates have less future beta movement.\par\vspace{.15cm}
Whether the lost opportunities outweigh avoided losses requires a trading evaluation.
\end{column}
\end{columns}
\vspace{.5cm}
\textbf{Next question:} can we estimate changes more precisely, so that fewer periods need to be excluded?
\vspace{.25cm}\take{Variance reduction offers a way to remain active while controlling noisy updates.}'''))
new.append(frame('A second idea: share evidence across related regressions',r'''
\small\vspace{.25cm}
Suppose several electricity contracts are each regressed on the same gas and carbon prices. A common market change may move their coefficients in a similar pattern.
\vspace{.3cm}
\begin{columns}[T]
\begin{column}{.46\textwidth}\textcolor{navy}{\textbf{Separate ridge corrections}}\par Shrink each contract's noisy update toward zero.\par\vspace{.15cm}Without an additional sharing structure, each contract estimates its own pattern.\end{column}
\begin{column}{.46\textwidth}\textcolor{teal}{\textbf{A shared low-rank correction}}\par Learn a common change direction from all contracts, with a different strength for each.\par\vspace{.15cm}Several noisy signals can help estimate the same pattern.\end{column}
\end{columns}
\vspace{.3cm}
\take{If changes share structure, pooling can reduce variance. If they differ, forcing a common pattern adds bias.}
\vspace{.15cm}Low rank can complement ridge; it is not uniformly better.
\refs{Bunea--She--Wegkamp (2011); Costa--Gardini--Paruolo (1997).}'''))
ex=get('A concrete example: learn one change across several contracts')
ex=ex.replace('Three electricity maturities use gas and carbon as features. Suppose their exposures change together:',r'\textbf{Illustrative example, not an empirical result.}\par Three electricity maturities use gas and carbon as features. Assume their coefficient changes share a pattern:')
ex=ex.replace('\n\\end{frame}',r'\refs{Reduced-rank regression: Bunea--She--Wegkamp (2011). Financial application: Costa--Gardini--Paruolo (1997).}'+'\n\\end{frame}')
new.append(ex)
rank=get('Low rank: several changes share one direction').replace("Each arrow is one contract's \\textbf{coefficient correction}, with gas and carbon as features.","\\textbf{Synthetic illustration:} each arrow is one contract's coefficient correction.")
rank=rank.replace('\n\\end{frame}',r'\refs{Bunea--She--Wegkamp (2011); Barratt--Dong--Boyd (2020/2021).}'+'\n\\end{frame}')
new.append(rank)
new.append(frame('Financial precedents and our application',r'''
\small\vspace{.25cm}
\renewcommand{\arraystretch}{1.45}
\begin{tabular}{P{4.2cm}P{8.5cm}}
\textbf{Costa et al. (1997)}&Reduced-rank asset-pricing regressions, applied to Italian stocks.\\
\textbf{Barratt et al. (2020/2021)}&Low-rank forecasting of SPY absolute returns across future horizons.\\
\textbf{Umlandt (2026, working paper)}&Time-varying reduced-rank coefficient matrices in an asset-pricing application.\\
\end{tabular}
\vspace{.35cm}
\textcolor{navy}{\textbf{Our proposed application}}\par
Keep the existing models and estimate a shared correction across related contracts:
\[B_{\rm new}=B_{\rm old}+\Delta,\qquad \operatorname{rank}(\Delta)\le r.\]
\take{Can sharing the correction improve prediction relative to separate ridge updates?}
\refs{\href{https://doi.org/10.1111/1468-0084.00055}{Costa--Gardini--Paruolo (1997)}; \href{https://stanford.edu/~boyd/papers/pdf/low_rank_forecasting.pdf}{Barratt--Dong--Boyd (2020/2021)}; \href{https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6726366}{Umlandt (2026)}.}'''))
new.append(get('Thank you'))
assert len(new)==20
document=s[:s.index(r'\begin{frame}')]+ '\n\n'.join(new)+'\n\\end{document}\n'
document=document.replace('\n\\vspace','\n\\par\\vspace')
(R/'cointegration_updates_revised.tex').write_text(document)
