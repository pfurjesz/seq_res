# Revised presentation

This 20-slide revision implements the blue and black annotations in the supplied 22-page PDF. The marked case-study, eigenvalue, comparison, memory and theorem slides were removed; the four-settings grid and online multiple-regime setting now follow the introduction. The Thank you slide is retained.

## Build
Run `pdflatex -interaction=nonstopmode -halt-on-error cointegration_updates_revised.tex` twice from this directory. To regenerate the edited source and synthetic cointegration figure, run `python3 revise.py` first (requires numpy and matplotlib). The generator reads the included previous_source.tex snapshot.

## Data and figure provenance
The cointegration figure is synthetic and constructed so y = 2 + 1.5 x + u, with a random-walk x and stationary AR(1) u. The electricity example and low-rank illustration are pedagogical, not empirical financial results.

The filtering results reproduce saved notebook output for a 120-day log-price regression of SPY on QQQ using Yahoo Finance adjusted data beginning in 2015. There are 2,452 evaluated observations; the filter retains 1,340 and excludes 1,112. Mean future absolute coefficient change falls from approximately 0.091855 to 0.076697 on retained dates. This is a conditional stability result, not demonstrated trading profitability. Pair selection uses the first 504 returns and overlaps the evaluation sample, so the analysis is explicitly exploratory. The original per-date data were not available for independent re-estimation in this revision. verified_numbers.json preserves numerical checks for the illustrations.

Paper references are retained on slides; explanatory footer comments are removed. The sensitivity identities distinguish adding an observation from the removal-and-addition in a rolling window. The reduced-rank proposal is presented as a hypothesis, with a bias trade-off and no claim of uniform superiority over ridge.
